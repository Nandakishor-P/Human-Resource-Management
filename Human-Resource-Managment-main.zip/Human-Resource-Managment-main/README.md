# Human-Resource-Management-System


## Project Description

This project is developed to incorporate data structures into the helpful resources of managing the human resources of any company and with an objective to 
help the corporate sector in managing their human resources and other issues which are related to it. The project is built with keeping in mind the idea of 
hierarchical architecture of organizing the staff present in a company. At the top we have the managing director being assisted by  a team of two managers. 
The two managers are being assisted by another subordinate teams for each of them. 

This project also caters to the needs of recruiting employees to the company, managing their tasks,for announcing anything and salary along with their 
phone book directories. In this project the use of data structures such as linkedlist, queue, stack, priority queue, arrays, binary tree etc. have been 
made extensively so that the efficiency of the program can be increased in order to increase the productivity of the program.


## Features

1. Applying for the company - A person can apply for the company
2. Recuitment - Manager will call the applicants in an order in which they applied
3. To-Do list - Director and manager can give tasks to the employees.
4. Announcements - Director can give announcements to his sub-ordinates.
5. Salary - Director can give salary to manager and manager can give salary to employee, it works as a hierarchical system.
6. Contact List - Manager can view the mobile numbers of the employees.
